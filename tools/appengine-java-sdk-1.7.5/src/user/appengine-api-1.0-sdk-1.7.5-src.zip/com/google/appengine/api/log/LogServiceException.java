// Copyright 2011 Google Inc. All Rights Reserved.

package com.google.appengine.api.log;

/**
 * Log errors apart from InvalidRequestException.  These errors will generally
 * benefit from retrying the operation.
 *
 *
 */
public final class LogServiceException extends RuntimeException {
  /**
   * Constructs a new LogServiceException with an error message.
   * @param errorDetail Log service error detail.
   */
  LogServiceException(String errorDetail) {
    super(errorDetail);
  }
}
