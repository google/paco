// Copyright 2010 Google Inc. All Rights Reserved.

package com.google.appengine.api.oauth;

/**
 * {@code OAuthRequestException} is thrown when a request is not a valid OAuth
 * request.
 *
 */
public class OAuthRequestException extends Exception {
  private static final long serialVersionUID = -5165727630822127728L;

  public OAuthRequestException(String message) {
    super(message);
  }
}
