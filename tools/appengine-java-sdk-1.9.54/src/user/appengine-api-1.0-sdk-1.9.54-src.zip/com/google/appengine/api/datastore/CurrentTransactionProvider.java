// Copyright 2011 Google Inc. All Rights Reserved.
package com.google.appengine.api.datastore;

/**
 * Internal interface describing an object that provide the current
 * transaction.
 *
 */
interface CurrentTransactionProvider {
  Transaction getCurrentTransaction(Transaction defaultValue);
}
