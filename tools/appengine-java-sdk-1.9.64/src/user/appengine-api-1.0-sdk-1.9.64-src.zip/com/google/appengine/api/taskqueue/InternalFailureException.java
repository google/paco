// Copyright 2010 Google Inc. All rights reserved.
package com.google.appengine.api.taskqueue;

/**
 * Internal task queue error.
 *
 */
public class InternalFailureException extends RuntimeException {
  private static final long serialVersionUID = -9056679159100665761L;

  public InternalFailureException(String detail) {
    super(detail);
  }
}
